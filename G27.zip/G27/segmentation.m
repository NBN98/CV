function [mask] = segmentation(left,right, varargin)
    % Creates a mask which seperates the foreground from the background
    % based on two tensors of two cameras
    %
    % left: Tensor of N left camera frames
    % right: Tensor of N right camera frames
    %
    % Segmentation properties:
    %
    %       SegMode         Defines which segmentation mode is to be used
    %                       ('median_difference'| 
    %                        'background_difference'|'weird_variance_based'|
    %                        'GmmVar_(default)')
    %
    %       RightGrayLeft   Is defined if the right frame tensor is
    %                       actually the frames of the left camera but 
    %                       convert to the gray scale colour space
    %
    %       For 'GmmVar_(default)' opitional Params:
    %                       block_sz: Size of Convex Hulle default [64 64]
    %                       mirror_cut: Cut Mirros default 0
    %                       cutoff_threshold: Cut noise default 250
    %                       block_sz: Size of Convex Hulle default [64 64]
    %
    %       For 'median_difference' opitional Params:
    %                       last_mask: Mask of last run
    %----------------------------------------------------------------------
               
                            
    valid_mode = @(x) or(ischar(x), isstring(x));

    p = inputParser; 
    p.addRequired('left');
    p.addRequired('right');

    p.addParameter('SegMode', 'GmmVar_(default)', valid_mode);
    p.addParameter('RightGrayLeft', false,  @(x) islogical(x));
    p.addParameter('last_mask', 0, @(x) isnumeric(x));
    p.addParameter('cutoff_threshold', 250, @(x) isnumeric(x));
    p.addParameter('block_sz', [64, 64], @(x) isequal(size(x, 2), 2));
    p.addParameter('mirror_cut', 0, @(x) isnumeric(x));


    parse(p, left, right, varargin{:});

    left = p.Results.left;
    right = p.Results.right;
    mode = p.Results.SegMode;
    right_gray_left = p.Results.RightGrayLeft;  % Dazu kommt noch was vom mir keine Sorge
    
    %choose mask as input for <last_mask> in challenge.m and initialize it with zero in the first
    %iteration
    last_mask = p.Results.last_mask;
    
    % variable cutoff threshold for gmm var method
    th_cutoff = p.Results.cutoff_threshold; 
    block_sz = p.Results.block_sz;
    mirror_cut = p.Results.mirror_cut;

    if right_gray_left
        assert(isequal(length(size(right)), 3),'Right is not a tensor of gray scale images.')
    end
    
    mask = zeros(size(left, 1, 2));
    
    
    if isequal(mode, 'median_difference')
        %works ideally for N=4, needs additional parameter "last_mask"
        
        %subsample images, to speed up calculations
        %also works as a simple lowpass-filter, to smooth out signal
        left = left(1:2:end,1:2:end,:,:);

        %convert images to grayscale
        img = zeros(size(left,1,2,4));
        for i=1:size(left,4)
          img(:,:,i) = rgb2gray(left(:,:,:,i));
        end
        
        %structuring elements of various size for morphological operations
        se = strel('disk',4);
        se2 = strel('disk',7);
        se3 = strel('disk',1);
        se4 = strel('disk',3);
        
        %calculate the median of the input images
        median_img = median(img,3); 
        
        %calculate the normalized squared difference from the median, which is somewhat similar to the variance 
        var_imgs = 1/(size(img,3)-1) * sum((img-median_img).^2,3)/255;        

        var_imgs = imclose(var_imgs,se);
        %erode image with small struc element to get rid of noise
        var_imgs = imerode(var_imgs,se3);
        %repeatedly apply dilate and closing operation to smooth out mask
        %and ideally to get a closed hull around each person
        var_imgs = imdilate(var_imgs,se2);
        var_imgs = imclose(var_imgs,se4);
        var_imgs = imdilate(var_imgs,se2);
        var_imgs = imclose(var_imgs,se4);
        %set last 25 rows to white, so that holes "going out" of the image
        %can also be filled out
        var_imgs(end-15:end,:) = 255;
        %fill out the holes inside the persons with imfill
        var_imgs = imfill(var_imgs,'holes');
        %finally apply erosion, such that the found mask is closer around
        %the actual persons contour
        var_imgs = imerode(var_imgs,se4);
        var_imgs = imerode(var_imgs,se4);
        var_imgs = imerode(var_imgs,se4);
        var_imgs = imerode(var_imgs,se3);
        %remove the ones in the last few rows
        var_imgs(end-15:end,:) = 0;

        %resize mask to original size
        mask = imresize(var_imgs,2);
        %add mask with the mask in the last step to get a even more stable
        mask(mask<0.65) = 0;
        mask = mask + 1/3*last_mask;
        
        %thresholding to get binary map
        mask(mask>=0.8) = 1;
        mask(mask<0.8) = 0;
        
        %lastly apply the final morphological operator to fill a hole,
        %which was created, when the two masks were added
        mask = imfill(mask,'holes');
    
    elseif isequal(mode, 'background_difference')
        
        N = 3;
        
        store = cell(1,1);
        
        % Store converted first and third image in cell array
        for i = 1:2:N
            % Convert to YCbCr
            img = ictRGB2ycocg(left(:,:,:,end-N+i));
            % img = imgaussfilt(img,2);
            % img = imgradient(img, 'CentralDifference');
            store{i,1} = img;
        end
        
        
        % Concatenate images
        back_model = cat(3, store{:,1}); 
        % Calculate median of the two images
        back_model = median(back_model,3);
        
        % Basic foreground calculation
        foreground = imabsdiff(store{end},back_model);                                         
        % Filter out salt and pepper noise with median filter
        foreground = medfilt2(foreground,[3,3]); 
        % Threshold foreground
        foreground = th(foreground);
        
        mask = foreground;
        
        % Define structure elements and size for the morphological operations
        struct_element1 = strel('square', 3);
        struct_element2 = strel('square',50);
        struct_element3 = strel('square',30);
        struct_element4 = strel('square', 20);
        
        % Apply morphological operators
        mask = imerode(mask, struct_element1);
        
        mask = imdilate(mask, struct_element2);                                   
        mask = imerode(mask, struct_element3);
        % % % mask = imfill(mask, 'holes');
        mask = bwconvhull(mask, 'objects');
        mask = imerode(mask, struct_element4);
        
        % mask = bwareafilt(mask, 2, 'Largest');
        
        mask = double(mask);

        
    elseif isequal(mode, 'mean_substraction_method')
    %% Mean Substraction Method
    % Preprocessing: RGB to Gray image, variance calculation
    if ~right_gray_left
        for i = 1:size(left,4)
            left_gray(:,:,i) = double(rgb2gray(left(:,:,:,i)))/255 ;
        end
    else
        left_gray =double(right);
    end
    left_ref = double(left_gray(:,:,:));
    %imshow(left_ref(:,:,1))
   
    mask = blockproc(left_gray(:,:,1), [50, 50], @(block_struct) w_segmentation(block_struct.data, left_ref, block_struct.location));
    
    % Set up shapes
    sse2 = strel('disk',20);
    sse3 = strel('disk',1);
    sse4 = strel('disk',20);
    sse6 = strel('disk',25);

    
    % Apply morphologic operators
    mask = imerode(mask,sse3);
    mask = imdilate(mask,sse6);
    mask = imclose(mask,sse2);
    mask = imerode(mask,sse4);


    mask = blockproc(mask, [100,100], @(block_struct) bwconvhull(block_struct.data, 'objects'));

        
    elseif isequal(mode, 'GmmVar_(default)')
        
        th_sep = 31;
        th_fill = 67;
        
        if right_gray_left
            img = right;
        else
            img = uint8(zeros(size(left,1,2,4)));
            for i=1:size(left,4)
                img(:,:,i) = rgb2gray(uint8(left(:,:,:,i)));
            end
        end
    
        last_n_imgs(:, :, 1:size(left, 4)-1) = double(img(:, :, 2:end));
        median_img = median(last_n_imgs,3);
        var_imgs = 1/(size(left, 4)-2) * sum((last_n_imgs-median_img).^2,3);
        rbgmask = var_imgs/255;
        rbgmask(rbgmask >= 1) = 1;
        rbgmask = medfilt2(rbgmask);

        foregroundDetector = vision.ForegroundDetector('NumGaussians', 3, ...
                                                'NumTrainingFrames', min(3, size(left, 4)), ...
                                                'InitialVariance', 30^2);

        for i = 1:size(left, 4)
             Fmask = foregroundDetector(img(:, :, i));
        end

        mask = zeros(size(left,1,2)); 

        [i,j] = find(Fmask>0);
        y = abs(j(1:end-1)-j(2:end));      

        sep_points = find(y>th_sep);
        if isempty(sep_points)
            BW1 = uint8(rbgmask(min(i):max(i), min(j):max(j)));
            BW1 = addEdges(BW1);
            BW2 = imfill(imclose(BW1, true(th_fill)), 'holes');
            BW2 = blockproc(BW2, block_sz, @(block_struct) bwconvhull(block_struct.data));
            mask(min(i):max(i), min(j):max(j)) = BW2;
        else
            for k = 1:length(sep_points)+1
                tmp_i = i;
                tmp_j = j;
                if k > length(sep_points)
                    tmp_i(1:sep_points(k-1)) = [];
                    tmp_j(1:sep_points(k-1)) = [];
                elseif k == 1
                    tmp_i(sep_points(k)+1:end) = [];
                    tmp_j(sep_points(k)+1:end) = [];
                else
                    tmp_i(sep_points(k)+1:end) = [];
                    tmp_j(sep_points(k)+1:end) = [];
                    tmp_i(1:sep_points(k-1)) = [];
                    tmp_j(1:sep_points(k-1)) = [];
                end
                if numel([min(tmp_i):max(tmp_i), min(tmp_j):max(tmp_j)]) < th_cutoff
                    continue;
                end
                BW1 = uint8(rbgmask(min(tmp_i):max(tmp_i), min(tmp_j):max(tmp_j)));
                BW1 = addEdges(BW1);               
                BW2 = imfill(imclose(BW1, true(th_fill)), 'holes');
                BW2 = blockproc(BW2, block_sz, @(block_struct) bwconvhull(block_struct.data));
                if nnz(BW2) < mirror_cut
                    continue;
                end
                mask(min(tmp_i):max(tmp_i), min(tmp_j):max(tmp_j)) = BW2;
            end
        end
        
    else
        error("SegMode does not exist")
    end  
end

function mask = w_segmentation(left, left_ref, pos)
%% Mean Substraction method
%Parameters:
%     weights: is the weight by which the future frames are weighted by
%     thres: bias + fac*stdd_m: bias gives the general background which should be 

% Calculate block size handed by bloickproc
block_size = size(left);

% Seperate reference images from current image
ref = left_ref(pos(1):pos(1)+block_size(1)-1, pos(2):pos(2)+block_size(2)-1, :);

% Calcualate weights for ref images
weights = 1:-0.05:(1.05-0.05*size(ref, 3));
weights = reshape(weights, 1,1,length(weights));
%Apply weights on reference image
ref = weights.*ref;

% Calculate mean of reference images
mu = sum(ref, 3)/size(left_ref,3);

% Substract mean from all given images
left_minus_mean = left - mu;

% Take abs and mean 
abs_left_minus_mean = abs(left_minus_mean);
stdd_m = mean2(left_minus_mean);

% calculate threshold for block
thres = 0.043 + 1.2*stdd_m;

% Apply Thresholding
abs_left_minus_mean(abs_left_minus_mean>=thres) = 1;
abs_left_minus_mean(abs_left_minus_mean<thres) = 0;
mask = abs_left_minus_mean;



end


%% General Functions
% Convert RGB image to Y image (luminance)

function ycbcr = ictRGB2ycocg(rgb)
    ycbcr(:,:,1) = rgb(:,:,1)*0.25 + rgb(:,:,2)*0.5 + rgb(:,:,3)*0.25;
end
        
% Thresholding function, very straight-forward

function image = th(image)                                                 
    image(image < 10) = 0;
    image(image > 10) = 255;
end

function upBW = addEdges(BW)
    upBW = BW;
    try
        x = find(BW(end-1, :) == 1);
        if ~isempty(x)
            upBW(end, x(1):x(end)) = 1;
        end
    catch
        upBW = BW;
    end
end

