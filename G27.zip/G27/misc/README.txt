# Computer Vision Challenge 2020 Gruppe 27

Dynamische Trennung von Hinter- und Vordergrund einer Bilder Sequenz. 

Achtung!   
Für eine bessere Übersicht können Sie README.html aufrufen. Falls Sie einen Markdown Editor haben erzielt README.md den selben Effekt. Dies ist der Fall, da diese Dateiformate Bilder unterstützen.

## Kompilieren/ Builden/ Testen

Um unser Programm verwenden zu können benötigt ihr folgendes:

- MATLAB (vorzugsweise >2019b)
- Computer Vision Toolbox
- Image Processing Toolbox

## Verwendung der GUI

### Start Fenster

Zum Öffnen der GUI/ des Start Fensters muss der Befehl:
start_gui
in der MATLAB Command Line eingegeben werden, dies öffnet das GUI Fenster.

Zu Beginn ist es nicht möglich die Variabeln zu setzen. Um die Funktionalität des Programms zu testen, ist das befolgen der nächsten Schritte notwendig.

#### 1. Image Directory

Links Klick auf den Button "Image Directory". Danach seid ihr in der Lage den Ordner auszuwählen, mit welchen ihr das Programm verwenden/testen wollt. 

Nachdem ihr das gemacht habt, sollte der Button für "Image Directory" grün aufleuchten.

#### 2. Setze Linke und Rechte Kamera

In diesem Schritt müsst ihr nun die Parameter für die Kameras setzen, abhängig davon welches Kamera Datenset ihr verwenden wollt. Zur Auswahl habt ihr für Links: 1 oder 2 und für Rechts: 2 oder 3.

Auch hier sollte sich die Farbe zu grün ändern, falls ein valider Ordner ausgewählt wurde. Falls nicht, färbt sich die Fläche rot. Wenn nichts verändert wurde, bleiben die Flächen grau.

#### 3. Auswahl vom "Start Frame" und von "N"

In diesem Schritt wird sowohl das Bild ausgewählt, bei welchem im Ordner begonnen wird ("Start Frame"), als auch das "N" welches besagt wie viele konsekutive Bilder für die Bearbeitung verwendet werden.
Achtet auf sinnvolle Eingaben dieser Parameter. Die default Parameter, mit welchem die gezeigten Ergebnisse erreicht wurden, werden am Ende dieser README dargestellt.

Falls die Parameter richtig/sinnvoll gesetzt wurden, sollten sich die Schaltflächen grün färben. Falls dies nicht der Fall ist, erscheinen diese rot. Falls die default Parameter verwendet werden, bleiben diese grau.

#### 4. Render Modus

Hier wird nun unter "Mode" der Modus ausgewählt mit welchen gerendert werden soll.
Hier gibt es 4 Modi:

- foreground: Der Hintergrund wird auf schwarz gesetzt. Der Vordergrund im Bild wird so wenig wie möglich verändert.
- background: Der Vordergrund wird auf schwarz gesetzt und nurnoch der Hintergrund ist zu sehen.
- overlay: Vordergrund und Hintergrund werden mit gut unterscheidbaren Farben transparent eingefärbt.
- substitute: Ersetzt den Hintergrund durch einen auswählbaren, statischen Hintergrund oder durch einen virtuellen Hintergrund (Bonus Task)

Im Default wird foreground verwendet.
Für den Modus "substitute" muss noch ein Bild oder ein Video (Bonus Task) ausgewählt werden. Zur Auswahl stehen folgende Formate: avi, mp3, mp4, jpg und png.

Nach korrekter Auswahl sollte auch dieses Feld grün aufleuchten.

#### 5. Zusätzliche Parameter

Im letzten Schritt müssen nur noch die zusätzlichen Parameter gesetzt werden. Hier seid ihr sowohl in der Lage den Namen des generierten Videos und die Segmentierungsmethode auszuwählen,
als auch den speziellen Warp Button zu aktivieren, mit welchem ihr in der Lage seid, die Laufzeit des Programms für manche Segmentierungs Methoden zu beschleunigen.


#### 6. Starten

Falls alle Parameter richtig gesetzt wurden, muss jetzt nur noch der "Apply"-Button gedrückt werden und das Programm sollte starten.
Nach dem drücken des "Apply"-Button wird die voraussichtliche Zeitdauer innerhalb des Buttons angegeben.

#### 7. Ende und Rendering

Nachdem der Algorithmus abgeschlossen ist, seid ihr nun in der Lage das Video zu betrachten. Den erfolgreichen Abschluss des Algorithmus erkennt ihr daran, dass nun der "Apply"-Button grün aufleuchtet.

Das Video sollte sofort nachdem der Prozess von "Apply" fertig ist, anfangen.

Der "Play"-Button startet das Video.
Der "Pause"-Button pausiert das Video.
Der "Step(mit Pfeilen nach links)"-Button ein Frame in die Vergangenheit.
Der "Step(mit Pfeilen nach rechts)"-Button ein Frame in die Zukunft.
Der obere "Schleifen"-Button lässt das Video in einer Endlosschleife laufen.
Der untere "Schleifen"-Button startet das Video wieder neu.

Achtung! Falls das Video nicht startet, solltet ihr in der Lage sein über den "Open Video in MATLAB Video Player"-Button die Video Datei zu öffnen.

#### 8. Extra: Open Video Matlab Video Player

Es ist auch möglich den "Open Video in MATLAB Video Player"-Button zu verwenden um das momentane Video oder eines der bereits fertiggestellten Videos abzuspielen.

## Ordner Struktur

Um den reibungslosen Ablauf des Programms zu garantieren muss die Ordnerstruktur der Aufgabenstellung eingehalten werden.
Falls sich andere Dateien in den Ordnern befinden, kann die Integrität des Programms nicht garantiert werden.

## Resultate

Zum Erhalten dieser Resultate wurde ein PC verwendet, welcher mit einer AMD Ryzen 3600 und 16 GB RAM (Taktfrequenz von 3433 MHz) ausgestattet ist. Das Einlesen und Auslesen aller Daten wurde mit einer HDD getestet.

### Default Parameter

| Methode               |  N   | L | R | Start Frame |
|-----------------------|:----:|:-:|:-:|------------:|
| Median Difference     |  4   | 1 | 1 | 0           |
| GMM with Var.         |  4   | 1 | 1 | 0           |
| Background Difference |  2   | 1 | 1 | 0           |
| Mean Subtraction      |  3   | 1 | 1 | 0           |

### Laufzeit in Sekunden (Maximal 1800 Sekunden)

| Methode                  | P1E_S1 | P1L_S3 | P2E_S2 | P2E_S4 | P2E_S5 | P2L_S5|
|--------------------------|:------:|:------:|:------:|:------:|:------:|-------:|
| Median Difference        |571.924 | 1059.9702| 762.5529| 1750.0294| 245.3028| 197.8779|
| GMM with Var.            |810.8174 | 1440.6 | 1016.0 | 1604.1 | 324.5415 | 323.3943 |
| GMM with Var. Warp Speed |608.66   | 1059.60 | 755.50 | 1222.71 | 248.2697 | 236.3902 |
| Background Difference    |362.6164 | 662.5718| 477.2497| 1213.1215| 160.2963| 129.8009|
| Mean Subtraction         |789.2325| 1448.736 | 1049.7501 | 1727.6621| 315.1004| 281.0069|
| Mean Subtraction Warp Speed |596.7883| 1075.1883| 754.4675| 1209.9115| 211.5091| 202.3691|

### Mean Square Error

| Methode               | 493 P1E_S1 | 678 P1L_S3 | 1059 P2L_S5 | 635 P2E_S2 | 903 P2E_S4 | 541 P2E_S5 |
|-----------------------|:------:|:------:|:------:|:------:|:------:|-------:|
| Median Difference     | 0.0834 | 0.0406 | 0.1324 | 0.0648 | 0.0276 | 0.1227 |
| GMM with Var.         | 0.0583 | 0.0187 | 0.0283 | 0.0296 | 0.0122 | 0.0337 |
| Background Difference | 0.0926 | 0.0417 | 0.0695 | 0.0357 | 0.0189 | 0.0700 |
| Mean Subtraction     | 0.0810 | 0.0368 | 0.1194 |  0.0317  | 0.3791 | 0.1197 |

