classdef ImageReader < handle
  % Add class description here
  properties
      % properties as described in project description. 
      % counter: is intialized with value given by input argument 'start'
      %   (default value = 0), keeps track of the current frame of the
      %   dataset to be loaded
      source;
      L_cam;
      R_cam;
      counter;
      N_frames;
      left_cam_imgs_path;
      right_cam_imgs_path;
      right_left_gray;
  end
  
  methods
      %constructor ImageReader
      %takes 3 required arguments 'src','L','R' and 2 optional arguments
      %'start' and 'N'
      % src: directory path to the camera scenes of interest. Input parser
      %      makes sure that not arbitrary char arrays can be passed
      % L: Camera number for the left camera, can only take values of {1,2}
      % R: Camera number for the right camera, can only take values of {2,3}
      % start: optional (default=0) refers to the starting frame, from which
      %        the scene is supposed to be loaded
      % N: optional (default=1) defines how many additional frames are
      % supposed to loaded in each loop
      function obj = ImageReader(src,L,R,varargin)
          p = inputParser;
          validSource = @(x) isfolder(x); 
          addRequired(p,'src',validSource);
          validL = @(x) isnumeric(x) && (x==1 || x==2);
          addRequired(p,'L',validL);
          validR = @(x) isnumeric(x) && (x==2 || x==3);
          addRequired(p,'R',validR);
          validStart = @(x)validateattributes(x,{'numeric'},{'integer','>=',0});
          addOptional(p,'start',0,validStart);
          validN = @(x)validateattributes(x,{'numeric'},{'integer','>=',1});
          addOptional(p,'N',1,validN);
          validRightLeftGray = @(x) islogical(x); 
          addParameter(p, 'RightGrayLeft', false, validRightLeftGray)
          
          parse(p,src,L,R,varargin{:});
          
          obj.source = p.Results.src;
          obj.L_cam = p.Results.L;
          obj.R_cam = p.Results.R;
          obj.N_frames = p.Results.N;
          obj.counter = p.Results.start;
          obj.right_left_gray = p.Results.RightGrayLeft;
          
          %load all directories of given source: get the directories, i.e.
          %the Cam folders back
          cam_directories = dir(obj.source);

          %query the directories to find the correct Cam number for each Camera
          %what is happending here: checks, if the directory name ends with the
          %number given by L_cam or R_cam respectively
          %returns a path
          left_cam_dir = cam_directories(contains({cam_directories.name},['C',num2str(obj.L_cam)]) & [cam_directories.isdir]);
          right_cam_dir = cam_directories(contains({cam_directories.name},['C',num2str(obj.R_cam)]) & [cam_directories.isdir]);
          %we are interested in the directory path
          left_cam_path = fullfile(obj.source,left_cam_dir.name,'**/*');
          right_cam_path = fullfile(obj.source,right_cam_dir.name,'**/*');

          obj.left_cam_imgs_path = dir(left_cam_path);
          obj.right_cam_imgs_path = dir(right_cam_path);

          obj.left_cam_imgs_path = obj.left_cam_imgs_path(contains({obj.left_cam_imgs_path.name}, {'jpg'}));
          obj.right_cam_imgs_path = obj.right_cam_imgs_path(contains({obj.right_cam_imgs_path.name}, {'jpg'}));
      end
      
      

      function [left, right, loop] = next(obj) 
          
          % left_cam_imgs_path and right_cam_imgs_path are directory structures containing all the images files 
          % I ASSUMED THAT THE FILES ARE ALREADY ORDERED CHRONOLOGICALLY,
          % IF THIS IS NOT THE CASE ANYMORE, THIS STEP HAS TO BE DONE AS
          % WELL (but once would be enough, as it is saved as a
          % property of the class object
          
          %just checking, whether the indices exceed the size of the
          %structures
          %returns the structure of image files, which are supposed
          %to be returnd in this step
          if length(obj.left_cam_imgs_path) > obj.counter+obj.N_frames+1
            left_cam_images_files = obj.left_cam_imgs_path(obj.counter+1:obj.counter+obj.N_frames+1);
            right_cam_images_files = obj.right_cam_imgs_path(obj.counter+1:obj.counter+obj.N_frames+1);
            loop = 0;
            obj.counter = obj.counter + 1;
          else
            left_cam_images_files = obj.left_cam_imgs_path(obj.counter+1:end);
            right_cam_images_files = obj.right_cam_imgs_path(obj.counter+1:end);
            loop=1;
            obj.counter = 0;
          end
          
          num_files = length(left_cam_images_files);
          
          % allocate array to add the images in: 
          % dimension given by: 600x800x3x(N+1)
          left = uint8(zeros([600,800,3,obj.N_frames+1]));
          if obj.right_left_gray
              right = uint8(zeros([600,800,obj.N_frames+1]));
          else
              right = uint8(zeros([600,800,3,obj.N_frames+1]));
          end

              
          
          
          %actually load the images and concatenates them into the tensors
          %left and right respectively
          for i=1:min(obj.N_frames+1,num_files)
              im_left = imread(fullfile(left_cam_images_files(i).folder,left_cam_images_files(i).name));
              if obj.right_left_gray
                im_right = rgb2gray(im_left);
                %convert the image files into double before returning --> necessary or not?
                right(:,:,i) = im_right;
              else
                im_right = imread(fullfile(right_cam_images_files(i).folder,right_cam_images_files(i).name));
                %convert the image files into double before returning --> necessary or not?
                right(:,:,:,i) = double(im_right);
              end
              %convert the image files into double before returning --> necessary or not?
              left(:,:,:,i) = double(im_left);
          end
          
          
      end
  end
      

end