function [result] = render(frame, mask, bg, render_mode)
    % Masks the left camera picture and renders the frame depending on the
    % mode
    % @param frame: Current picture if the left camera
    % @param mask: Binary mask containing the human shape
    % @param bg: RGB picture which replaces the current camera background
    % @param mode: foreground (black background), background (black foreground),
    %              overlay (different colors from background and foreground),
    %              substitute (bg will be used as background)
    
    bg = double(bg);
    frame = double(frame);
    mask = double(mask);
    
    if isequal(render_mode, 'foreground')
        result = frame .* mask;
        
    elseif isequal(render_mode, 'background')
        result = frame .* (1-mask);
        
    elseif isequal(render_mode, 'overlay')
        background = frame;
        background(:, :, 3) = 255 * ones([size(frame, 1), size(frame, 2)]);
        
        foreground = frame;
        foreground(:, :, 1) = 255 * ones([size(frame, 1), size(frame, 2)]);

        foreground = foreground .* mask;
        background = background .* (1-mask);
        result = foreground + background;
        
    elseif isequal(render_mode, 'substitute')
        resized_bg = imresize(bg, [size(frame, 1), size(frame, 2)]);
        result = frame .* mask + resized_bg .* (1-mask);
    end
    
    result = uint8(result);
end