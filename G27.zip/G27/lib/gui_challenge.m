%% Computer Vision Challenge 2020 challenge.m
%clear all;
%initialize variables, which are required (are probably also in config.m)
%store = 0; %Unnecessary we always store a picture

%% Generall Settings
% Group number:
group_number = 27;

% Group members:
members = {'Salihu Driton', 'Jim Zhao', 'Tim Benthien', 'Alexander Prommesberger', 'Wisam Waad Noori'};

% Email-Address (from Moodle!):
mail = {'driton.salihu@tum.de', 'jim.zhao@tum.de', 'tim.benthien@tum.de', 'alexander.prommesberger@tum.de', 'wisam.waad@tum.de'};

loop = 0;

%% Start timer here
tic

% Generate Movie
% basic structure to test, that images are loaded correctly and no endless
% loops are created
%% Setting Parameter
src = app.src;
L = (app.L);
R = (app.R);
start = app.start;
N = app.N;
right_gray_left = logical( app.set_RitghtGrayLeft);
bg = 0; %default/dummy parameter
bgVidObj = 0;
store = 1;

vidobj = VideoWriter(app.video_save_name);
if store 
    open(vidobj)
end

ir = ImageReader(src,L,R,start,N,'RightGrayLeft', right_gray_left);

if isempty(app.set_background_path)
    true;
elseif strcmpi(app.set_background_path(end-2:end), 'jpg') || strcmpi(app.set_background_path(end-2:end), 'png')
    bg = imread(app.set_background_path);
else
    bgVidObj = VideoReader(app.set_background_path);
end

setsegmode = app.seg_mode;
mode = app.mode;  % substitute für background
%%%%%%%%%%%%%%%%%%%%%%%

mirror_cut = 0;
if or(contains(src, "P2E_S4"), contains(src, "P1L_S3"))
    mirror_cut = 15000;
elseif contains(src, "P2E_S5")
    mirror_cut = 17500;
end

%% Genrating mask, rendering and saving Video
fprintf('Starting the Video Segmentation\n')
while loop ~= 1
  % Get next image tensors
    if and(isequal(mode, 'substitute'), ~isequal(bgVidObj , 0))
        if ~hasFrame(bgVidObj)
            bgVidObj.CurrentTime = 0.0;
        end
        bg = double(readFrame(bgVidObj));  
    end

    [left, right, loop] = ir.next();
    [mask] = segmentation(left, right, 'SegMode', setsegmode, 'RightGrayLeft', right_gray_left, ...
                          'mirror_cut', mirror_cut); % look at function for optional arguments
    [result] = render(left(:, :, :, end), mask, bg, mode);  % Input von left picture ist zu besprechen!!!!
    if store
        writeVideo(vidobj, result)
    end
end

if store
    close(vidobj)
end

%% Stop timer here
elapsed_time = toc
