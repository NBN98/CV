%% Computer Vision Challenge 2020 settings.m
clear all;
%% Generall Settings
% Group number:
group_number = 27;

% Group members:
members = {'Driton Salihu', 'Jim Zhao', 'Tim Benthien', 'Alexander Prommesberger', 'Wisam Waad Noori'};

% Email-Address (from Moodle!):
mail = {'driton.salihu@tum.de', 'jim.zhao@tum.de', 'tim.benthien@tum.de', 'alex.prommesberger@tum.de', 'wisam.waad@tum.de'};


%% Setup Image Readert
% Specify Scene Folder 
src = uigetdir();

% Select Cameras
L = 1;
R = 2;

% Choose a start point
start = 0;

% Choose the number of succseeding frames
N = 4;


%% Additional Setting - readme!
right_gray_left = false; %to run with Warp-speed, set to true
set_background_path = '';
seg_mode = 'GmmVar_(default)';
%% Output Settings
% Output Path
dest = "output.avi";

% Load Virual Background
bg = 0; %default value. To load virtual background, use line below to and comment this line
%bg = imread("path/to/your/background/image");

% Select rendering mode
mode = "foreground"; %four possible modes: "foreground"(default), "background", "overlay", "substitute"

% Store Output
store = true;