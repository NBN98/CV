README

This program is a convenient tool for separating the background and the foreground in video frames, which allows a replacement of the background in a video stream. It contains six parts: ImageReader, Segmentation, Rendering, Configuration, Challenge and a GUI for an easy use of this tool.

------------------------------------------------------------------
(A) Execute without GUI

(1) Run the script 'config.m' (Configuration)
You can set all parameters which are needed for the foreground detection and background substitution for a desired video sequence in the ChokePoint-dataset. 
* Note: 
    We offer a 'bonus' function, which allows you to substitute the background with a video. (Format: avi, mp4 ...) This results a very small modification of required parameters. Please choose a mode for background (bg_mode), it should be either 'still image' or 'video'. Please give the fullpath and filename as a string (bg_name).
* Recommendation: 
    The frames in dataset ChokePoint are of size 600x800. Please choose a picture/video with appropriate size. They do not need to be of the same size, since we considered the case in our code. However, for a better visual experience, they should not be too large or too small.
* Important:
    Consider the trade off between the running time and the quality of the result, we recommend you to choose N = 4.

(2) Run the script 'challenge.m' [Please do not modify parameters in this script]
This script reads and processes all frames of the video from a given starting point to the end of the video sequence, and generate a new rendered video. If you choose to store the rendered video (in config.m, see step 1), a '.avi' file will be written into the given output path. At the end of the program, we print the elapsed time.


------------------------------------------------------------------
(B) Execute with GUI

(1) Parameter setting
  Scene folder
In this panel choose your scene folder which contains three subfolders representing three cameras. The name of the scene folder and subfolders should be specified as following format: e.g. P1E_S1, P1E_S1_C1, P1E_S1_C2, P1E_S1_C3. Then select the left camera and right camera.

  Start point
is the index  where you want to start. The images before this index will not be processed. Your start point should not exceed the number of images.

  Background
In Background panel choose your background mode, and select the image or video(anywhere in your computer) as your background. With 'image mode ' your generated folder and video will be named with 'I' in the end and for 'video mode' with 'V'.

  Mode and Generate video 
Mode depicts in which way you want to process image and In 'Generate video' panel you can specify the path you want to save the result. The Load button functions as the preparation of video including reading image, segmentation, Rendering, generated processed images and video. Once the Load button is pressed, please wait
until the video control is avaliable.

(2) video control 
start, stop, loop, close
Once the start button is pressed, two videos are displayed in the right side. The upper one is original, the other one is processed video. Stop button pauses video, Loop button will repeat it. Press close button if you want to quit gui.


------------------------------------------------------------------
(C) Most important functions:

(1)ImageReader 
realizes the image loading. Based on previously set parameters, it will provide the proper amount of frames.
    ir = ImageReader(src, L, R, start, N) will create a class. The input src is the data directory, where the frames are saved. The input L and R is the index of three cameras, which are used to provide the images for the left and right correspondently. The input start indicates the start point to load frames, and the N describes how many frames will be loaded together. 
    After initialization of the class ir, frames will be loaded by execute the command [left, right, loop] = ir.next(). The output left and right are two tensors. They have a size of 600*800*(N+1)*3, and save the frames for the further use. The output loop is a control variable. The loop will be 0 when the frames in the folder are keeping loaded to the left and right. If the frames in the folder is not enough, all the rest frames will be loaded to the tensors and the loop will be set to 1.

(2)Segmentation 
detects which part of a frame belongs to the foreground, i.e. all things that are not still, in the current video frame. After finding the foreground, the function will generate a binary mask, which has the same size as the original frame. A pixel in the mask takes value 1, if the respective pixel in the original frame belongs to the detected foreground.
mask = segmentation(left, right) takes as input 2 tensor (size MxNx(K*3),K>=2)of video frames provided by link and right cameras, i.e. the output of ir.next() [see point (1)].


(3)Rendering 
is a function that can operate on the mask obtained from the previous Segmentation to modify the foreground or background of a given image frame. 
    result = render(frame, mask, bg, render_mode) creates the rendered frame. The input frame is the current video frame. The input mask is the result obtained by the previous 
Segmentation. The input bg is another picture for substitution. The input render_mode gives the desired render method. There are in total 4 different modes: 
    (i)  'foreground': only display the foreground information in the frame. 
    (ii) 'background': only display the background information in the frame. 
    (iii)'overlay'   : dye the background and foreground with distinguishable transparent colours. (Default: background-green, foreground-red)
    (iv) 'substitute': substitute the background of the frame with the given background image (bg). 


------------------------------------------------------------------
*Important: 
Our software is designed and well tested to be executed either in UNIX or in WINDOWS system.
Our codes are based on MATLAB_R2020a. If you face some problem with a previous release, which will normally not happen, please try to update your MATLAB to the latest release. 
If the folder name is such as P2E_S2_C1.2, please change this to standard form (P2E_S2_C1 or P2E_S2_C2).
Additionally, you need to install the Image Processing Toolbox in MATLAB.
The better substitued videos of high quality(N = 4) were already uploaded to the goole drive (https://drive.google.com/drive/folders/14rmLk5nkE3XBx1DOvJurbxNX-E5aC7q3?usp=sharing). If you have interest, you can check these videos.

You can find out more details by reading the document in attachment. Also when you have more queations, you might find the solutions in this document.