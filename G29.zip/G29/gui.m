function varargout = gui(varargin)
% GUI MATLAB code for gui.fig
%      GUI, by itself, creates a new GUI or raises the existing
%      singleton*.
%
%      H = GUI returns the handle to a new GUI or the handle to
%      the existing singleton*.
%
%      GUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in GUI.M with the given input arguments.
%
%      GUI('Property','Value',...) creates a new GUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before gui_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to gui_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help gui

% Last Modified by GUIDE v2.5 11-Jul-2020 19:46:35

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @gui_OpeningFcn, ...
                   'gui_OutputFcn',  @gui_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before gui is made visible.
function gui_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to gui (see VARARGIN)
clc

set(handles.Start_btn,'Enable','off');
set(handles.Stop_btn,'Enable','off');
set(handles.Loop_btn,'Enable','off');

set(handles.Load_btn,'Enable','off');





% Choose default command line output for gui
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes gui wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = gui_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in sf_btn.
function sf_btn_Callback(hObject, eventdata, handles)
% hObject    handle to sf_btn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
         handles.path = uigetdir();
         set(handles.scene_path,'String',handles.path);
         guidata(hObject,handles);


% --- Executes on button press in Load_btn.
function Load_btn_Callback(hObject, eventdata, handles)
% hObject    handle to Load_btn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
         % set right, left camera, startpoint
         tic;
         L = get(handles.LeftC,'Value');
         R = get(handles.RightC,'Value') + 1;
         startpoint = str2double(get(handles.s_edit,'String'));
         
         %transfer to imageReader
         ir_cv = ImageReader(handles.path, L, R, "N",4,"start",startpoint);
         
         loop = 0;
         counter = 0;
         
         % compatible with unix system
         if isunix
             all_folder = strsplit(handles.path,'/');
             scene_folder = char(all_folder(end));
             handles.scene_folder = scene_folder;
         else
             all_folder = strsplit(handles.path,'\');
             scene_folder = char(all_folder(end));
             handles.scene_folder = scene_folder;
         end
         
         % mode name for creating new folder
         Mode = cellstr(get(handles.Mode_P,'String'));
         index = get(handles.Mode_P,'Value');
         Mode = Mode{index};
         
         
        
         
         % achieve background mode(Bonus) and intact path
         
         backg_mode = get(handles.B_mode,'Value');
         bg_path_temp = handles.bg_path;
         
         % # of pictures in one loop
         N = 4;
         if backg_mode == 1
    
            path_saved = fullfile(handles.save_path,[Mode,'_',scene_folder,'_','I']);
            % create newfoler for storing processed_image
            mkdir(path_saved);
            
            bg = double(imread(bg_path_temp));

         % segmentation, render, store
            while loop ~= 1
                % Get next image tensors
                [left, right, loop] = ir_cv.next();
                % Generate binary mask
                [mask] = segmentation(uint8(left),uint8(right));
                % Render new frame
                if ~all(mask(:)==0)
                    counter = counter + 1;
                    result = render(left(:,:,ceil((N-1)/2)*3+1:ceil((N+1)/2)*3), mask,bg,Mode);
                    image_name = fullfile(path_saved,[Mode ,num2str(counter,'%.8i'),'.jpg']);
                    imwrite(result,image_name);
                end
            end
         else
             path_saved = fullfile(handles.save_path,[Mode,'_',scene_folder,'_','V']);
             % create newfoler for storing processed_image
             mkdir(path_saved);
             
             bg_v = VideoReader(bg_path_temp);
              while loop ~= 1
                 % Get next image tensors
                 [left, right, loop] = ir_cv.next();
                 % Generate binary mask
                 [mask] = segmentation(uint8(left),uint8(right));
                 % if Duration of bg_v is smaller than pictures,then replay
                 % it
                 if hasFrame(bg_v) == 0
                     bg_v.CurrentTime = 0;
                 end
                 bg_frame = double(readFrame(bg_v));    
                 % Render new frame
                 if ~all(mask(:)==0)
                    counter = counter + 1;
                    result = render(left(:,:,ceil((N-1)/2)*3+1:ceil((N+1)/2)*3), mask,bg_frame,Mode);
                    image_name = fullfile(path_saved,[Mode ,num2str(counter,'%.8i'),'.jpg']);
                    imwrite(result,image_name);
                 end
              end
          end
         
          % get name of image in the chosen scenefolder
          L = num2str(get(handles.LeftC,'Value'));
          video_path = fullfile(handles.path,[handles.scene_folder,'_','C',L]);
          imageNames_pre = dir(fullfile(video_path,'*.jpg'));
          imageNames_pre = {imageNames_pre.name}';
          
          % video object for original video
          vid_temp = VideoWriter(fullfile(handles.save_path,[handles.scene_folder,'.avi']));
          vid_temp.FrameRate = 30;
          open(vid_temp);
          
          % get name of processed_image 
          video_processed_path = path_saved;
          imageNames_processed = dir(fullfile(video_processed_path,'*.jpg'));
          imageNames_processed = {imageNames_processed.name}';
          
          % video object for processed_video
          if backg_mode == 1
             vid_temp_processed = VideoWriter(fullfile(handles.save_path,[Mode,'_',handles.scene_folder,'_','I','.avi']));
             vid_temp_processed.FrameRate = 30;
             open(vid_temp_processed);
          else
             vid_temp_processed = VideoWriter(fullfile(handles.save_path,[Mode,'_',handles.scene_folder,'_','V','.avi']));
             vid_temp_processed.FrameRate = 30;
             open(vid_temp_processed);
          end
          
          
          startpoint = str2num(get(handles.s_edit,'String'));
          
          % fill the video object with image.
          for i = startpoint+1:length(imageNames_pre)     
              img = imread(fullfile(video_path, imageNames_pre{i}));
              writeVideo(vid_temp,img);
          end
          for i = 1:length(imageNames_processed)
              img_processed = imread(fullfile(video_processed_path, imageNames_processed{i}));
              writeVideo(vid_temp_processed,img_processed);
          end
          
          close(vid_temp);
          close(vid_temp_processed);
          
          Vidobj = VideoReader(fullfile(handles.save_path,[handles.scene_folder,'.avi']));
          if backg_mode == 1
             Vidobj_processed = VideoReader(fullfile(handles.save_path,[Mode,'_',handles.scene_folder,'_','I','.avi']));
          else
             Vidobj_processed = VideoReader(fullfile(handles.save_path,[Mode,'_',handles.scene_folder,'_','V','.avi']));
          end
          handles.Vidobj = Vidobj;
          handles.Vidobj_processed = Vidobj_processed;
          guidata(hObject,handles);
          
          %set the start, stop, loop buuton accessible
          set(handles.Start_btn,'Enable','on');
          set(handles.Stop_btn,'Enable','on');
          set(handles.Loop_btn,'Enable','on');
          toc;
          


% --- Executes on button press in Start_btn.
function Start_btn_Callback(hObject, eventdata, handles)
% hObject    handle to Start_btn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
       %play the video 
       global Start_val
       Start_val = 1;
             while hasFrame(handles.Vidobj) && hasFrame(handles.Vidobj_processed) && Start_val == 1   % maybe here a while true
                Loop = getappdata(0,'loop_value');
                vidFrame = readFrame(handles.Vidobj);
                vidFrame_processed = readFrame(handles.Vidobj_processed);
                image(vidFrame,'Parent',handles.axes1);           
                image(vidFrame_processed,'Parent',handles.axes2);
                pause(1/handles.Vidobj.FrameRate);
                
             % check for the loop operation
                if handles.Vidobj.CurrentTime == handles.Vidobj.Duration && Loop == 1
                    handles.Vidobj.CurrentTime = 0;
                    handles.Vidobj_processed.CurrentTime = 0;
                end
                 
             end
         
         



% --- Executes on button press in Stop_btn.
function Stop_btn_Callback(hObject, eventdata, handles)
% hObject    handle to Stop_btn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
        global Start_val
        Start_val = 0;




% --- Executes on button press in Loop_btn.
function Loop_btn_Callback(hObject, eventdata, handles)
% hObject    handle to Loop_btn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
         setappdata(0,'loop_value',1);


% --- Executes on button press in Stop_btn.
function Save_btn_Callback(hObject, eventdata, handles)
% hObject    handle to Stop_btn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
         save_path = uigetdir();
         handles.save_path = save_path;
         guidata(hObject,handles);
         set(handles.Load_btn,'Enable','on');




% --- Executes on button press in Ini_btn.
function Ini_btn_Callback(hObject, eventdata, handles)
% hObject    handle to Ini_btn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
        


% --- Executes on button press in bg_btn.
function bg_btn_Callback(hObject, eventdata, handles)
         % return background path 
         [bg,bg_path] = uigetfile();
         handles.bg_path = [bg_path,bg]; %% you can use image anywhere in your computer
         guidata(hObject,handles);


function s_edit_Callback(hObject, eventdata, handles)
% hObject    handle to s_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of s_edit as text
%        str2double(get(hObject,'String')) returns contents of s_edit as a double


% --- Executes during object creation, after setting all properties.
function s_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to s_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in RightC.
function RightC_Callback(hObject, eventdata, handles)
% hObject    handle to RightC (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns RightC contents as cell array
%        contents{get(hObject,'Value')} returns selected item from RightC



% --- Executes during object creation, after setting all properties.
function RightC_CreateFcn(hObject, eventdata, handles)
% hObject    handle to RightC (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in LeftC.
function LeftC_Callback(hObject, eventdata, handles)
% hObject    handle to LeftC (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns LeftC contents as cell array
%        contents{get(hObject,'Value')} returns selected item from LeftC

         


% --- Executes during object creation, after setting all properties.
function LeftC_CreateFcn(hObject, eventdata, handles)
% hObject    handle to LeftC (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in Mode_P.
function Mode_P_Callback(hObject, eventdata, handles)
% hObject    handle to Mode_P (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns Mode_P contents as cell array
%        contents{get(hObject,'Value')} returns selected item from Mode_P


% --- Executes during object creation, after setting all properties.
function Mode_P_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Mode_P (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in Close_btn.
function Close_btn_Callback(hObject, eventdata, handles)
% hObject    handle to Close_btn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
        close(gui);


% --- Executes on selection change in B_mode.
function B_mode_Callback(hObject, eventdata, handles)
% hObject    handle to B_mode (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns B_mode contents as cell array



% --- Executes during object creation, after setting all properties.
function B_mode_CreateFcn(hObject, eventdata, handles)
% hObject    handle to B_mode (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
