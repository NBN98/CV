function [result] = render(frame, mask, bg, mode)
%is a function that can operate on the mask obtained from the segmentation 
%to modify the foreground or background of a given image frame. 

    switch lower(mode)
        case 'foreground'
            % set background to zero
            result = uint8(frame.*mask);
        case 'background'
            % set foreground to zero
            result  = uint8(frame.*(1-mask));
        case 'overlay'
            % Use green to dye the background; Use red to dye the foreground
            green = cat(3, zeros(size(mask)),ones(size(mask)), zeros(size(mask)));
            red = cat(3, ones(size(mask)),zeros(size(mask)), zeros(size(mask)));
            result  = uint8((frame-64+64.*green).*(1-mask)+(frame-64+64.*red).*mask);
        case 'substitute'
            sz_bg = size(bg);
            sz_fr = size(frame);
            % If the given background image is too small; Repeat along each
            % dimension
            if any(sz_bg < sz_fr)
                bg = repmat(bg,ceil(sz_fr(1)/sz_bg(1)),ceil(sz_fr(2)/sz_bg(2)));
            end
            % Cut the background to required size
            bg_cut = imcrop(bg,[0,0,size(frame,2),size(frame,1)]);
            result = uint8(frame.*mask+bg_cut.*(1-mask));
        otherwise
            error('Ungültige Methode! Invalid method!')
    end
    
end

