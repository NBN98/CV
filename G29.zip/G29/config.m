%% Computer Vision Challenge 2020 config.m
clear

%% Generall Settings
% Group number:
group_number = 29;

% Group members:
members = {'Haozhi Chen', 'Ming Gui', 'Yang Liu', 'Yushu Yang', 'Ge Zhang'};

% Email-Address (from Moodle!):
% mail = {'ga99abc@tum.de', 'daten.hannes@tum.de'};


%% Setup Image Reader
scene = '1';        % Choose the scene P : '1' or '2'
inout = 'L';        % Choose the status: 'L' or 'E'
sequence = '1';     % Choose the video sequence: '1','2','3','4','5'

% Give the folder path. You can either give a full path or a relative path.
folderpath = '/Users/yangyushu/Downloads/ChokePoint/';  %For example.
foldername = ['P',scene,inout,'_S',sequence];

% Specify Scene Folder
SRC = [folderpath,foldername];

% Select Cameras
L_cam = 2;          % 1 or 2 
R_cam = 3;          % 2 or 3

% Choose a start point
% start = randi(1000);
start =0;

% Choose the number of succseeding frames (recommand: N=4)
N = 4;

% initialize image reader
ir = ImageReader(SRC, L_cam, R_cam, 'start',start,'N',N);


%% Output Settings
% Output Path
dest = "/Users/yangyushu/Downloads/videos/"; %For example.

% Load Virual Background
% Select background mode: 'still image' 'video'. 
bg_mode = 'still image'; 
bg_name = '/Users/yangyushu/Downloads/G29/background/artists.jpg';
% bg_name = 'small_bg.avi';

switch lower(bg_mode)
    case 'still image'
        bg = double(imread(bg_name));
    case 'video'
        bg_r = VideoReader(bg_name,'CurrentTime',2); 
    otherwise
        bg = zeros(1,1,3);
end

% Select rendering mode 'foreground', 'background', 'overlay', 'substitute'
render_mode = 'substitute';

% Store Output?
store = true;
