%% Computer Vision Challenge 2020 challenge.m

%% Start timer here
tic;

%% Generate Movie
loop = 0;
counter = 0;
im_sec_proc = cell(10000,1); % allocate storage for rendered video frames

%%
while loop ~= 1
   counter = counter + 1;
   
  % Get next image tensors
   [left, right, loop] = next(ir);
  % Generate binary mask
   mask = segmentation(uint8(left),uint8(right));
  
  % Read background frame from background video
   if strcmpi(bg_mode,'video')
       if ~hasFrame(bg_r)
          bg_r = VideoReader(bg_name,'CurrentTime',0); 
       end
       bg = double(readFrame(bg_r));
   end
   
  % Render new frame
  result = render(left(:,:,ceil((N-1)/2)*3+1:ceil((N+1)/2)*3), mask,bg,render_mode);
  
  % Save the rendered frame
  im_sec_proc{counter} = result;

end
  
%% Write Movie to Disk
if store
    % create a unique file name and a video
    c = clock;
    v_name = [num2str(c(2)),num2str(c(3)),num2str(c(4)),num2str(c(5)),...
        render_mode,'_P',scene,inout,num2str(L_cam),'_N',num2str(N),'.avi'];
    v = VideoWriter(fullfile(dest,v_name));

    % Write frames into the video
    open(v);
    for i =  1:numel(im_sec_proc)
        if isempty(im_sec_proc{i})
            break
        end
        writeVideo(v,im_sec_proc{i});
    end
    close(v);
end

%% Stop timer here
elapsed_time = toc;
fprintf('The total elapsed time is %.2f seconds!\n',elapsed_time);