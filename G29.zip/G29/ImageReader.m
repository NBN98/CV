classdef ImageReader < handle
  % The ImageReader class realized the image loading from the ChokePoint dataset. 
  % properties: src, L, R, start, N
  % methods: ir = ImageReader(SRC, L_cam, R_cam, varargin)
  % [left, right, loop] = next(ir)
  
  
  properties % set the properties and the default values
      src           % source 
      L             % left camara index (1 or 2)
      R             % right camara index (2 or 3) 
      start = 0;    % starting point of video (default:0)
      N = 1;        % read N+1 frames each time (default:1)
  end
  
  methods
    %% Construct an image reader
    function ir = ImageReader(SRC, L_cam, R_cam, varargin)
      p = inputParser;
      default_start = 0;
      default_N = 1;
      p.addParameter('start',default_start,@(x)validateattributes(x,{'numeric'},{'integer','>=',0}));
      p.addParameter('N',default_N,@(x)validateattributes(x,{'numeric'},{'integer','>=',1}));
      p.parse(varargin{:});
      ir.src = SRC;
      if (L_cam == 1 || L_cam == 2) < 3 % L should be within {1,2} 
         ir.L = L_cam;
      else
         error('L must be 1 or 2'); 
      end
      if (R_cam == 2 || R_cam == 3) && (R_cam ~= L_cam)
         ir.R = R_cam;
      else
         error('R must be 2 or 3, and L do not equal to R');
      end
      ir.start = p.Results.start;
      ir.N = p.Results.N;
    end
    %% generate the image tensors left and right
    function [left, right, loop] = next(ir)
      % initialize tensors
      left  = zeros(600,800,(ir.N+1)*3);
      right = left;


      %get directory
      if isunix
         all_folder = strsplit(ir.src,'/');
         scene_folder = char(all_folder(end));
         dir_left = fullfile(ir.src,[scene_folder,'_','C',num2str(ir.L),'/']);
         dir_right = fullfile(ir.src,[scene_folder,'_','C',num2str(ir.R),'/']);
      else
         all_folder = strsplit(ir.src,'\');
         scene_folder = char(all_folder(end));
         dir_left = fullfile(ir.src,[scene_folder,'_','C',num2str(ir.L),'\']);
         dir_right = fullfile(ir.src,[scene_folder,'_','C',num2str(ir.R),'\']);
      end



      % left & right
      image_path_left_list = dir(strcat(dir_left,'*.jpg')); % scan all images for left
      image_number_left = length(image_path_left_list); %number of images in the folder
      image_path_right_list = dir(strcat(dir_left,'*.jpg')); % scan all images for right
      if (ir.start+1)+ir.N < image_number_left % if the numbers of current images enough, load N+1 images to left tensor
          tag = 0;
          for i = (ir.start+1):(ir.start+1)+ir.N
             tag = tag+1;
             image_left = image_path_left_list(i).name;
             image_right = image_path_left_list(i).name;
             left(:,:,(1+3*(tag-1)):(3+3*(tag-1))) = imread(fullfile(dir_left,image_left));
             %fprintf('left: %s\n',fullfile(dir_left,image_left));
             right(:,:,(1+3*(tag-1)):(3+3*(tag-1))) = imread(fullfile(dir_right,image_right));
          end
          loop=0;
          ir.start=ir.start+1;
      else % the numbers of current images not enough, just load the remaining images and stop the loop
          tag = 0;
          for i = (ir.start+1) : image_number_left
             tag = tag +1; 
             image_left = image_path_left_list(i).name;
             image_right = image_path_right_list(i).name;
             left(:,:,(1+3*(tag-1)):(3+3*(tag-1))) = imread(fullfile(dir_left,image_left));
             %fprintf('left: %s\n',i,ir.start,fullfile(dir_left,image_left));
             right(:,:,(1+3*(tag-1)):(3+3*(tag-1))) = imread(fullfile(dir_left,image_right));
          end
          loop = 1;
          ir.start=0;
      end         
    end
  end
end

