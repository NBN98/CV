function mask = segmentation(left,right)
  % This function detect the foreground of the current left frame by using
  % a sequence of neighbouring frames. The a mask for the detected
  % foreground is generated.

    %% Check if the imput has right dimension 
    [M,N,D] = size(left);
    if mod(D,3) ~= 0 
      error('Tensoren left und right muessen eine Dimension von MxNx(K*3) haben!');
    end
    
    %% Save the K frames as a Cell variable 
    K = D/3;
    % cell for images initialization 
    imleft = cell(K);
    % save images in the tensor as separated frames
    for i = 1:K
      imleft{i} = left(:,:,3*(i-1)+1:3*i);
    end
    
    %% Create union of masks found by comparing current frame with all another
    % Current frame is the one in the middle
    target_frame_idx = round(K / 2);
    candidate_frame_idx = 1:K;
    candidate_frame_idx(candidate_frame_idx == target_frame_idx) = [];
    
    % Initialization the total_mask with zeros
    total_mask = zeros(M,N);
    
    % Add all masks together 
    for idx = candidate_frame_idx
        total_mask = total_mask + image2mask(imleft,idx,target_frame_idx);
    end
    
    % Active region of the total mask should be the intersection of at
    % least ceil(K/2) individual masks
    total_mask(total_mask <  ceil(K/2)) = 0;
    total_mask(total_mask >= ceil(K/2)) = 1;

    %% Remove the part around people's body by using edge information of the still image
    % read current frame
    I11 = double(rgb2gray(imleft{target_frame_idx}));
    
    % Assumption of maximal distance from total mask to body boundaries
    % resulted by motion and imdilate
    n_p = 8;
    
    % Pad image and mask to avoid border effect
    I11_pad = padarray(I11,[n_p,n_p],'replicate');
    mask_pad =  padarray(total_mask,[n_p,n_p],'replicate');

    % Smallest region that must be included in the final mask
    mask_small = imerode(mask_pad,strel('disk',n_p-1));
    mask_small = mask_small(n_p+1:end-n_p,n_p+1:end-n_p);
    
    % edge detection inside the prospective foreground
    I11_fore = I11_pad.*mask_pad;
    I11_max = max(I11_fore(:));
    I11_scale = I11_pad./I11_max*255;
    edge_11 = edge(I11_scale,'Canny',[0.005 0.015]);
    
    % Construct a mask with edges (inside the total mask)
    m1 = mask_pad .* edge_11;
    m2 = imclose(m1,strel('disk',5));
    m2 = m2(n_p+1:end-n_p,n_p+1:end-n_p);
    m3 = imfill(m2,'holes');
    m3_pad = padarray(m3,[4,4],'replicate');
    for k = 1
        tmp = ones(2*k+1);
        tmp(2:end-1,2:end-1) = zeros(2*k-1);
        m3_pad = m3_pad & conv2(double(m3_pad),tmp,'same') > 0;
    end
    m3 = m3_pad(5:end-4,5:end-4);
    
    % fill the holes in the mask at the image border
    mask = padarray(m3,[1,0],1,'pre');
    mask = padarray(mask,[0,1],1,'post');
    mask = imfill(mask,'holes');
    mask = mask(2:end,1:end-1);
    mask = padarray(mask,[1,1],1,'post');
    mask = imfill(mask,'holes');
    mask = mask(1:end-1,1:end-1);
    mask = padarray(mask,[1,1],1,'pre');
    mask = imfill(mask,'holes');
    mask = mask(2:end,2:end);
    mask = padarray(mask,[0,1],1,'pre');
    mask = padarray(mask,[1,0],1,'post');
    mask = imfill(mask,'holes');
    mask = mask(1:end-1,2:end);
    mask = imclose(mask,strel('disk',5));
    mask = imerode(mask,strel('disk',5));
    
    % Combine the edge and smoothe the boundary of foreground
    mask = mask|mask_small;
    width = 11;
    kernel = ones(width) / width^2;
    blurryImage = conv2(double(mask), kernel, 'same');
    mask = blurryImage > 0.6;
    
    % For better visual feeling
%     G = fspecial('disk',5);
%     mask = imfilter(double(mask),G);
    
%     toc
end  

function mask = image2mask(imleft,idx1,idx2)
     [M,N,D] = size(imleft{idx1});
         
     % use the gray-scale image
     I11 = double(rgb2gray(imleft{idx1}));
     I12 = double(rgb2gray(imleft{idx2}));

     % calculate difference image over time 
     G = fspecial('disk');

     % Use the filtered image to calculate difference -> differences
     % resulted by noise can be removed easier
     I11_disk = imfilter(I11,G);
     I12_disk = imfilter(I12,G);
     diff_left = abs(I11_disk-I12_disk);
    
     % set threshold to remove most fetures resulted by noise 
     diff_left(diff_left<10) = 0;     
     
     if sum(diff_left(:))/(M*N)<0.015
         mask = zeros(M,N);
         return 
     end
     
     % fill the holes inclusive those at top and bottom boundaries
     diff_left = padarray(diff_left,[1,1],255,'post');
     diff_left = imfill(diff_left,'holes');
     diff_left = diff_left(1:end-1,1:end-1);
     % fill the holes at left and right boundaries
     diff_left = padarray(diff_left,[1,1],255,'pre');
     diff_left = imfill(diff_left,'holes');
     diff_left = diff_left(2:end,2:end);
     % combine the neighbouring features
     diff_left = imclose(diff_left,strel('disk',5));
     diff_left = imfill(diff_left,'holes');
     H = fspecial('gaussian',8);
     diff_left_H = imfilter(diff_left,H);
     diff_left_H(diff_left_H<10) = 0;
    
     % add additional features in mask by considering the edges of the
     % difference image
     diffeg = I11-I12;
     if all(diffeg(:)==0)
         error('repeated frame exists!')
     end
     
     % Generate the convexhull around moving object. In which an edge
     % detection should be performed
     width = 11;
     kernel = ones(width) / width^2;
     blurryImage = conv2(diffeg , kernel, 'same');
     ed_hull= blurryImage>5;%3.5;
     ed_hull = bwconvhull(ed_hull);
     ed_hull = imdilate(ed_hull,strel('disk',10));

     % Find edges with canny 
     diffeg(abs(diffeg)<2) = 0;
     ed = edge(diffeg,'Canny',[0.02 0.03]);   
     ed = imclose(ed,strel('disk',3));
     ed = ed.*ed_hull;
     
     % combine the difference mask and the edges
     mask = diff_left_H|ed;
     % enlarge parts of masks to combine them together
     mask = imdilate(mask,strel('disk',10));
     
     % Find foundarris of all parts 
     [B,L] = bwboundaries(mask,'noholes');
     pmf = hist(L(:),0:length(B));
     
     % Ignore patterns that is to small(assume they are results by noise)
     imBound = zeros(600,800);
     idx_list = find((pmf(2:end)>5000)==1);
     for j = idx_list
         boundary = B{j};
         x = (boundary(:,2)-1)*M+boundary(:,1);
         imBound(x) = 1;
     end
     mask = imfill(imBound);

     % enlarge parts of masks to combine them together
     mask = imdilate(mask,strel('disk',15));
     % fill the holes
     mask = imfill(mask);
     % shrink the foreground mask 
     mask = imerode(mask,strel('disk',20));
end