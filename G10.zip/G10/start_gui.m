function start_gui()
    % add gui subfolder to main path
    addpath(genpath('gui_app'));
    % opden gui app
    gui
end
