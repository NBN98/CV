function [result] = render(frame,mask,render_mode,bg)
  % This function allows to choose one the four possibel rendering modes 
  %(foreground, background, overlay, substitute)
  %Its results will be dispalyed on the GUI
    
    

subplot(1,2,1), 
imshow(frame)
drawnow
    if strcmp(render_mode,'foreground') 
        result(:,:,1)=frame(:,:,1).*uint8(mask);
        result(:,:,2)=frame(:,:,2).*uint8(mask);
        result(:,:,3)=frame(:,:,3).*uint8(mask);

    elseif strcmp(render_mode,'background') 
        result(:,:,1)=frame(:,:,1).*uint8(~mask);
        result(:,:,2)=frame(:,:,2).*uint8(~mask);
        result(:,:,3)=frame(:,:,3).*uint8(~mask);

    elseif strcmp(render_mode,'overlay') 
        %result=labeloverlay(labeloverlay(frame(:,:,1),~mask),mask);
        
        result(:,:,1)=  frame(:,:,1).*uint8(mask);
        result(:,:,2) = frame(:,:,1).*uint8(~mask);
        result(:,:,3) = zeros(600,800);
               
        %result=labeloverlay(frame(:,:,1).*uint8(mask),frame(:,:,1).*uint8(~mask));
        
    elseif strcmp(render_mode,'substitute') 
        if size(bg,1)>600 || size(bg,2) >800
            resized_bg = bg(1:600,1:800,:); %works only if bg bigger than 600x800 in both axes
        else 
            resized_bg = imresize(bg,[600,800]);
        end
        result_background=resized_bg.*uint8(~mask);
        size(resized_bg);
        result(:,:,1)=frame(:,:,1).*uint8(mask)+result_background(:,:,1);
        result(:,:,2)=frame(:,:,2).*uint8(mask)+result_background(:,:,2);
        result(:,:,3)=frame(:,:,3).*uint8(mask)+result_background(:,:,3);
        
    end
subplot(1,2,2), 
imshow(result)

drawnow   
  
  

end
