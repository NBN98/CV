%this function provides a binary mask for the provided images in left and
%right
function mask = segmentation(left, right)

%Load the current and the next images from the left camera 
%Convert the 2 RGB images to gray scale
gray_current=rgb2gray(left(:,:,1:3));
gray_next=rgb2gray(left(:,:,4:6));

%Convert the images to double
current_image = im2double(gray_current);
next_image = im2double(gray_next);


%Provide the lower and upper images based on the rate
rate = 0.15; %The toleration rate to detect a movement
lower_image =next_image-rate*next_image;
upper_image =next_image+rate*next_image;


%Set the corresponding idndices to 0 in mask1 if the difference between the
%next image and the lower or upper image does not exceed the value of the rate
mask = ones(size(current_image));%Initialize mask_1 to ones
mask( (upper_image > current_image & current_image > lower_image) ) = 0;



%Apply a Gaussian filter to our mask_1 in order to detect the noise
%(Blurry the noise)

threshold = 0.25; %Threshold needed to avoid the holes
sigma = 2; %Gauss parameter
mask = imgaussfilt(double(mask),sigma);

for i = 1:size(mask,1)
    for j = 1:size(mask,2)
        if mask(i,j)>threshold
            mask(i,j) = 1;
        else
            mask(i,j) = 0;
        end
    end
end

%The noise points are influenced by their neighborhood
%According to the threshold value, these points take the appropriate values to avoid the holes

mask = imfill(mask);


%Take out bounding boxes from our binary image
hBlobAnalysis = vision.BlobAnalysis('MinimumBlobArea', 6000, 'MaximumBlobArea', 300000);
[~, ~, bbox] = step(hBlobAnalysis, logical(mask));

%Merge the different bounding boxes that are even partially superposed
mask_0 = zeros(size(mask));

for j = 1:size(bbox,1)
    mask_0(bbox(j,2):(bbox(j,2)+ bbox(j,4))-1 , bbox(j,1):(bbox(j,1)+ bbox(j,3))-1 ) = 1;
end

[~, ~ , bbox] = step(hBlobAnalysis, logical(mask_0));



prefinal_mask = zeros(size(mask_0));
jump = 15 ; %The number of points that are not taken into account for the detection of boundaries
h = fspecial('sobel');% Sobel filter to detect edges


%If at least one blob is detected, compute mask, otherwise return black mask

if size(bbox,1) >= 1
    
    %loop over all detected blobs and make an individual mask
    for k = 1:size(bbox,1)
        
        
        %Apply sobel filter 
        prefinal_mask(:,:,k) = logical( imfilter(mask,h) + imfilter(mask,h') );
        
        %Down sampling the image for faster prcessing 

        jump_matrix = [1:size(current_image,2)];
        jump_matrix(mod(jump_matrix,jump)~=0)=0;
        jump_matrix(jump_matrix>0)=1;
        
       
        jump_matrix = repmat(jump_matrix,size(current_image,1),1);
       
        jump_matrix = reshape(jump_matrix,size(current_image,1),size(current_image,2));
        m = zeros(size(mask));
        m(bbox(k,2):(bbox(k,2)+ bbox(k,4))-1 , bbox(k,1):(bbox(k,1)+ bbox(k,3))-1 ) = 1;
        jump_matrix = m.*jump_matrix;
        
        
        
      
        boundary_points = prefinal_mask.*jump_matrix;
        [RowNrs,ColNrs] = find(boundary_points>0);
       
        %Detect the most exact shape of our final_mask
        drawing_idx = 0.5;
         boundary_ard_pts = boundary(RowNrs, ColNrs, drawing_idx);
        
        %Convert the detected shape to a binary mask
        prefinal_mask(:,:,k) = poly2mask(ColNrs(boundary_ard_pts),RowNrs(boundary_ard_pts),size(current_image,1),size(current_image,2));
    end
    %Merge the masks of all the above found bboxes 
    mask = logical(sum(prefinal_mask,3));
else
    mask= zeros(size(mask_0));
end

end