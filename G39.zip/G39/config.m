%% Computer Vision Challenge 2020 config.m

%% Generall Settings
% Group number:
 group_number = 'G39';

% Group members:
 members = {'Wael Chaouch','Mohamed Chefai','Mohamed Ben Ahmed','Ahmed Khalil Ben Mohamed'};

% Email-Address (from Moodle!):
 mail = {'ga86nez@mytum.de','ga45peg@mytum.de','ga45gux@mytum.de','ga86mel@mytum.de'};

 
%% Setup Image Reader
% Specify Scene Folder
%load('guioutput');
src = src;

% Select Cameras
R=Right;  
L=Left;
  

% Choose a start point
% start = randi(1000);
 start = Start;
% Choose the number of succseeding frames
 N = 3;

ir = ImageReader(src, L, R, start, N);


%% Output Settings
% Output Path

dest = "output.avi";
saveas_path = fullfile(save_as_path,dest);
% Load Virual Background
bg = imread(pg);

% Select rendering mode
render_mode = popval;

% Store Output?
store = true;
