
%this classdef checks if the provided inputs in config are right or not
%and will generate the left and right with 600*800*(N+1)*3 dimensions
%which will be used in segmentation

%'< handle ' in order to be able to update the values of the class's properties
classdef ImageReader < handle 
    properties 
        src
        L
        R
        start = 0
        N = 1
        loop = 0
    end
    methods

        function obj = ImageReader(varargin)
            num_inputs = size(varargin,2);
            %Check how many inputs have been provided by user
            if(num_inputs<5)%If less than 5, then start was not given as input
                value_src = varargin{1};
                value_L = varargin{2};
                value_R = varargin{3};
                value_N = varargin{4};
            elseif(num_inputs==5)
                value_src = varargin{1};
                value_L = varargin{2};
                value_R = varargin{3};
                obj.start = varargin{4}; %Setting the start property directly here
                value_N = varargin{5};
            else
                error('Only the start value is optional. Please enter 3 or 4 inputs.')
            end

            %Setting the L property
            if and(value_L~=1,value_L~=2)
                error('L must be either 1 or 2.')
            else
                obj.L = value_L;
            end

            %Setting the R property
            if or(and(value_R~=2,value_R~=3),value_R==value_L)
                errordlg('R must be either 2 or 3, and also different from L.')
               % error('R must be either 2 or 3, and also different from L.')
            else
                obj.R = value_R;
            end

            %Setting the src property
            obj.src = value_src;
            
            %Setting the N property
            obj.N = value_N;

        end
        
        function setStart(obj,value)
            obj.start = value;
        end

        function [left, right, loop] = next(obj)
            str = obj.src(end-5:end);
            path=fullfile(obj.src,str);
%             left_path = strcat(obj.src,'/',str,'_C',int2str(obj.L));
%             right_path = strcat(obj.src,'/',str,'_C',int2str(obj.R));
            left_path = strcat(path,'_C',int2str(obj.L));
            right_path = strcat(path,'_C',int2str(obj.R));
            left_directory = dir(strcat(left_path,'/*.jpg'));
            right_directory = dir(strcat(right_path,'/*.jpg'));
            numberTotalImagesLeft = size(left_directory,1);
            %numberTotalImagesRight = size(right_directory,1);
            left = [];
            right = [];
            read_images = 0;
            
            current_image_index = obj.start;
            
            while(and(read_images < obj.N+1,current_image_index<numberTotalImagesLeft))
                current_image_index = current_image_index+1;
                read_images = read_images+1;
                image_left_path = left_directory(current_image_index);
                image_right_path = right_directory(current_image_index);
                image_left_path = strcat(image_left_path.folder,'/',image_left_path.name);
                image_right_path = strcat(image_right_path.folder,'/',image_right_path.name);
                left = cat(3,left,imread(image_left_path));
                right = cat(3,right,imread(image_right_path));
                
            end
            size(left);
            loop = 0;
            if read_images<obj.N+1
                loop = 1;
                obj.start = 0;
                %setStart(obj,0);
            else
                obj.start = current_image_index;
            end           
            
        end
    end
end




