%% Computer Vision Challenge 2020 challenge.m

%% Start timer here
tic;

%% Generate Movie
%ir = ImageReader(src, L, R, start, N);
loop = ir.loop;
idx = 0;
do_not_stop = running_loop || ~loop;
%video_matrix = zeros(600,800,3,N+1);

  if store
    movie_obj = VideoWriter(saveas_path);
    movie_obj.FrameRate = 30/(N+1);
    open(movie_obj);
  end

while do_not_stop 
  idx = idx + 1;
  % Get next image tensors
  [left, right, loop] = ir.next();
  
  do_not_stop = running_loop || ~loop;
  if isempty(left)
      continue
  end
  % Generate binary mask
  [mask] = segmentation(left,right);
  
  % Render new frame
  frame = left(:,:,1:3);
  [result] = render(frame,mask,render_mode,bg);

  %% Write Movie to Disk

  if store
    writeVideo(movie_obj, result);
  end

end
close(movie_obj);

%% Stop timer here
elapsed_time = toc;
